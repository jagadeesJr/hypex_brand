<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BusinessAuthentications\AuthenticationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/




/* These for Brand & Crators/Professionals Registration, Login, verify Email to forgot password & Change password*/
Route::post("/brandRegistration", [AuthenticationController::class, "brandRegistration"])->name("brandregistration");
Route::post("/creatorsRegistration", [AuthenticationController::class, "creatorsRegistration"])->name("creatorsregistration");
Route::post("/creatorsLogin", [AuthenticationController::class, "creatorsLogin"])->name("creatorslogin");
Route::post("/brandLogin", [AuthenticationController::class, "brandLogin"])->name("brandlogin");
Route::post("/brandForgotPasswordVerifyEmail", [AuthenticationController::class, "brandForgotPasswordVerifyEmail"])->name("brandforgotpasswordverifyemail");
Route::post("/creatorForgotPasswordVerifyEmail", [AuthenticationController::class, "creatorForgotPasswordVerifyEmail"])->name("creatorforgotpasswordverifyemail");
Route::post("/brandForgotPasswordChangePassword", [AuthenticationController::class, "brandForgotPasswordChangePassword"])->name("brandforgotpasswordchangepassword");
Route::post("/creatorForgotPasswordChangePassword", [AuthenticationController::class, "creatorForgotPasswordChangePassword"])->name("creatorforgotpasswordchangepassword");




// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
