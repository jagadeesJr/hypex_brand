<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BrandBusiness;
use App\Models\OrderProducts;
use App\Models\ServiceBooking;

class Feedback extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'feedback';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'business_id',
        'service_id',
        'order_id',
        'title',
        'subtitle',
        'document',
    ];

    /**
     * Get the business that owns the feedback.
     */
    public function business()
    {
        return $this->belongsTo(BrandBusiness::class, 'business_id');
    }

    /**
     * Get the service that owns the feedback.
     */
    public function service()
    {
        return $this->belongsTo(ServiceBooking::class, 'service_id');
    }

    /**
     * Get the order that owns the feedback.
     */
    public function order()
    {
        return $this->belongsTo(OrderProducts::class, 'order_id');
    }
}
