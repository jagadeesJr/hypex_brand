<?php

namespace App\Models;

use App\Models\OrderProducts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class OrderPayments extends Model
{
    use HasFactory;
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'order_payments';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'order_id',
        'invoice_number',
        'total',
        'payment_status',
        'payment_id',
        'status',
    ];

    // Listen for the creating event
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($payment) {
            $latestPayment = OrderPayments::orderBy('id', 'desc')->first();
            $nextNumber = $latestPayment ? intval(substr($latestPayment->invoice_number, 2)) + 1 : 1;
            $payment->invoice_number = 'BROIN' . str_pad($nextNumber, 2, '0', STR_PAD_LEFT);
            // Generate random service_id
            $payment->payment_id = 'BROPID' . Str::upper(Str::random(10));
        });
    }

    /**
     * Get the order that owns the order payment.
     */
    public function order()
    {
        return $this->belongsTo(OrderProducts::class, 'order_id');
    }
}
