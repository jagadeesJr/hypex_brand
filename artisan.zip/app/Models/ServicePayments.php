<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class ServicePayments extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'service_payments';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'booking_id',
        'invoice_number',
        'total',
        'payment_status',
        'payment_id',
        'status',
    ];

    // Listen for the creating event
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($service) {
            $latestService = ServicePayments::orderBy('id', 'desc')->first();
            $nextNumber = $latestService ? intval(substr($latestService->invoice_number, 2)) + 1 : 1;
            $service->invoice_number = 'BRSPIN' . str_pad($nextNumber, 2, '0', STR_PAD_LEFT);
            // Generate random payment id
            $service->payment_id = 'BRSPID' . Str::upper(Str::random(10));
        });
    }

    /**
     * Get the booking that owns the service payment.
     */
    public function booking()
    {
        return $this->belongsTo(ServiceBooking::class, 'booking_id');
    }
}
