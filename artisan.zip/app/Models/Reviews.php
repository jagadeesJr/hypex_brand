<?php

namespace App\Models;

use App\Models\BrandBusiness;
use App\Models\OrderProducts;
use App\Models\ServiceBooking;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reviews extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'reviews';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'business_id',
        'service_id',
        'order_id',
        'title',
        'subtitle',
        'rating',
    ];

    /**
     * Get the business that owns the review.
     */
    public function business()
    {
        return $this->belongsTo(BrandBusiness::class, 'business_id');
    }

    /**
     * Get the service that owns the review.
     */
    public function service()
    {
        return $this->belongsTo(OrderProducts::class, 'service_id');
    }

    /**
     * Get the order that owns the review.
     */
    public function order()
    {
        return $this->belongsTo(ServiceBooking::class, 'order_id');
    }
}
