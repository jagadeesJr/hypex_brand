<?php

namespace App\Models;

use App\Models\BrandBusiness;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class OrderProducts extends Model
{
    use HasFactory;
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'order_products';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'business_id',
        'order_id',
        'product_details',
        'total',
        'payment_status',
        'status',
        'tag',
    ];

    // Listen for the creating event
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($order) {
            $latestOrder = OrderProducts::orderBy('id', 'desc')->first();
            $nextNumber = $latestOrder ? intval(substr($latestOrder->branch_code, 2)) + 1 : 1;
            $order->order_id = 'BROID' . str_pad($nextNumber, 2, '0', STR_PAD_LEFT);
        });
    }

    /**
     * Get the business that owns the order product.
     */
    public function business()
    {
        return $this->belongsTo(BrandBusiness::class, 'business_id');
    }
}
