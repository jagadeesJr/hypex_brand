<?php

namespace App\Http\Controllers\BusinessAuthentications;

use App\Http\Controllers\Controller;
use App\Models\BrandAuthentication;
use App\Models\CreatorsAuth;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthenticationController extends Controller
{

    /**
     * The function `brandRegistration` registers a brand by validating input data, hashing the
     * password, and storing brand information in the database.
     *
     * @param Request request The `brandRegistration` function is a PHP function that handles the
     * registration of a brand user. It takes a `Request` object as a parameter, which likely contains
     * the data submitted during the brand registration process.
     *
     * @return \Illuminate\Http\JsonResponse `brandRegistration` function returns a JSON response with the status, message, and
     * brand data. If the validation fails, it returns an error response with validation errors. If an
     * exception occurs during the process, it returns an error response with a message indicating that
     * something went wrong along with the exception message.
     */
    public function brandRegistration(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|unique:brand_users,email',
                'brand_name' => 'required',
                'first_name' => 'required',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            // Hash the password before storing it
            $hashedPassword = bcrypt($request->password);
            // Register the brand
            $brand = BrandAuthentication::create([
                'email' => $request->email,
                'brand_name' => $request->brand_name,
                'first_name' => $request->first_name,
                'password' => $hashedPassword,
                'last_name' => $request->last_name,
                'phone_number' => $request->phone_number,
                'status' => 1,
            ]);

            return response()->json(['status' => 1, 'message' => 'Brand registered successfully', 'brand_id' => $brand->id]);

        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

    /**
     * The function `creatorsRegistration` registers creators with validation and hashing of passwords
     * in PHP.
     *
     * @param Request request The `creatorsRegistration` function is a PHP function that handles the
     * registration of creators. It takes a `Request` object as a parameter, which likely contains data
     * submitted by a user through a form or an API request.
     *
     * @return \Illuminate\Http\JsonResponse function `creatorsRegistration` returns a JSON response with different data based on
     * the outcome of the registration process.
     */
    public function creatorsRegistration(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|unique:creator_users,email',
                'first_name' => 'required',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            // Hash the password before storing it
            $hashedPassword = bcrypt($request->password);
            // Register the brand
            $creator = CreatorsAuth::create([
                'email' => $request->email,
                'first_name' => $request->first_name,
                'password' => $hashedPassword,
                'last_name' => $request->last_name,
                'phone_number' => $request->phone_number,
                'status' => 1,
            ]);

            return response()->json(['status' => 1, 'message' => 'creator registered successfully', 'creator_id' => $creator->id]);

        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

    /**
     * The function `creatorsLogin` attempts to authenticate a user with email and password, returning
     * a JSON response based on the authentication result.
     *
     * @param Request request The `creatorsLogin` function is a controller method that handles the
     * login process for creators. It takes a `Request` object as a parameter, which contains the data
     * submitted by the user trying to log in.
     *
     * @return \Illuminate\Http\JsonResponse function `creatorsLogin` returns a JSON response with different data based on the
     * outcome of the login attempt. Here are the possible return scenarios:
     */
    public function creatorsLogin(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            // Attempt to log in the user
            $credentials = $request->only('email', 'password');

            if (Auth::guard('creator')->attempt($credentials)) {
                // Get the authenticated user
                $user = Auth::guard('creator')->user();

                return response()->json([
                    'status' => 1,
                    'message' => 'Login successful',
                    'user' => $user,
                ]);
            } else {
                return response()->json([
                    'status' => 0,
                    'message' => 'Invalid email or password',
                ]);
            }

        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

    /**
     * The function `BrandLogin` in PHP validates user credentials and attempts to log in a user with a
     * brand guard, returning appropriate JSON responses based on the outcome.
     *
     * @param Request request The `BrandLogin` function you provided is a PHP function that handles the
     * login process for a brand user. It validates the email and password provided in the request,
     * attempts to log in the user using the `Auth` facade with the `brand` guard, and returns a JSON
     * response based on the
     *
     * @return \Illuminate\Http\JsonResponse `BrandLogin` function returns a JSON response based on the validation and
     * authentication process. Here are the possible return scenarios:
     */
    public function brandLogin(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            // Attempt to log in the user
            $credentials = $request->only('email', 'password');

            if (Auth::guard('brand')->attempt($credentials)) {
                // Get the authenticated user
                $user = Auth::guard('brand')->user();

                return response()->json([
                    'status' => 1,
                    'message' => 'Login successful',
                    'user' => $user,
                ]);
            } else {
                return response()->json([
                    'status' => 0,
                    'message' => 'Invalid email or password',
                ]);
            }

        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

  /**
   * The function `brandForgotPasswordVerifyEmail` verifies the email provided in the request for a
   * brand's forgotten password.
   *
   * @param Request request The `brandForgotPasswordVerifyEmail` function is a PHP function that
   * verifies the email provided in the request. Here's a breakdown of the function:
   *
   * @return \Illuminate\Http\JsonResponse `brandForgotPasswordVerifyEmail` function is returning a JSON response based on the
   * validation and database check for the provided email address. Here are the possible return
   * scenarios:
   */
    public function brandForgotPasswordVerifyEmail(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            if (BrandAuthentication::where("email", '=', $request->email)) {
                return response()->json(['status' => 1, "message" => "Email verified successful"]);
            } else {
                return response()->json(['status' => 0, "message" => "Could not found email"]);
            }

        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

    /**
     * The function `creatorForgotPasswordVerifyEmail` verifies the email address of a creator for
     * password reset in PHP.
     *
     * @param Request request The `creatorForgotPasswordVerifyEmail` function is designed to verify if
     * a creator's email exists in the database. However, there is an issue in the code logic. The `if
     * (CreatorsAuth::where("email", '=', ->email))` condition will always return true because
     * it is
     *
     * @return \Illuminate\Http\JsonResponse function `creatorForgotPasswordVerifyEmail` returns a JSON response with a status
     * code and a message based on the validation and database check results.
     */
    public function creatorForgotPasswordVerifyEmail(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            if (CreatorsAuth::where("email", '=', $request->email)) {
                return response()->json(['status' => 1, "message" => "Email verified successful"]);
            } else {
                return response()->json(['status' => 0, "message" => "Could not found email"]);
            }
        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

    public function brandForgotPasswordChangePassword(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'new_password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 0, 'error' => $validator->errors()]);
            }

            $brand = CreatorsAuth::where("email", '=', $request->email);
            if($brand){

            }
            if (CreatorsAuth::where("email", '=', $request->email)) {
                return response()->json(['status' => 1, "message" => "Email verified successful"]);
            } else {
                return response()->json(['status' => 0, "message" => "Could not found email"]);
            }
        } catch (Exception $e) {
            return response()->json(['status' => 0, 'error' => 'Something went wrong', "message" => $e->getMessage()]);
        }
    }

}
